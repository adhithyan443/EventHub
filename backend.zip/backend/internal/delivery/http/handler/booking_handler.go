package handler

import (
	"errors"
	"log/slog"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"

	"github.com/adhithyan443/EventHub/backend/internal/domain"
	"github.com/adhithyan443/EventHub/backend/internal/usecase/booking"
)

type BookingHandler struct {
	bookingUsecase *booking.BookingUsecase
	logger         *slog.Logger
}

func NewBookingHandler(
	bookingUsecase *booking.BookingUsecase,
	logger *slog.Logger,
) *BookingHandler {
	if logger == nil {
		logger = slog.Default()
	}
	return &BookingHandler{
		bookingUsecase: bookingUsecase,
		logger:         logger,
	}
}

// GetMyBookings handles GET /api/v1/bookings.
func (h *BookingHandler) GetMyBookings(c *gin.Context) {
	userID, ok := authenticatedUserID(c)
	if !ok {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "unauthorized",
		})
		return
	}

	bookings, err := h.bookingUsecase.GetMyBookings(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to retrieve bookings",
		})
		return
	}

	if bookings == nil {
		bookings = []domain.Booking{}
	}

	c.JSON(http.StatusOK, gin.H{
		"data": bookings,
	})
}

// GetBookingByID handles GET /api/v1/bookings/:id.
func (h *BookingHandler) GetBookingByID(c *gin.Context) {
	userID, ok := authenticatedUserID(c)
	if !ok {
		c.JSON(http.StatusUnauthorized, gin.H{
			"error": "unauthorized",
		})
		return
	}

	bookingID, err := uuid.Parse(c.Param("id"))
	if err != nil || bookingID == uuid.Nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": "invalid booking ID",
		})
		return
	}

	result, err := h.bookingUsecase.GetBookingByID(
		c.Request.Context(),
		userID,
		bookingID,
	)
	if err != nil {
		if errors.Is(err, domain.ErrBookingNotFound) {
			c.JSON(http.StatusNotFound, gin.H{
				"error": "booking not found",
			})
			return
		}

		c.JSON(http.StatusInternalServerError, gin.H{
			"error": "failed to retrieve booking",
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"data": result,
	})
}
