package repository

import (
	"log/slog"

	"github.com/adhithyan443/EventHub/backend/internal/domain"
	"gorm.io/gorm"
)

type TransactionManager struct {
	db     *gorm.DB
	logger *slog.Logger
}

type transactionRepositories struct {
	userRepo                 *UserRepository
	pendingRegistrationRepo  *PendingRegistrationRepository
	passwordResetTokenRepo   domain.PasswordResetTokenRepository
	organizerApplicationRepo domain.OrganizerApplicationRepository

	organizerRepo            domain.OrganizerRepository
	organizerProfileRepo     domain.OrganizerProfileRepository
	organizerAddressRepo     domain.OrganizerAddressRepository
	organizerBankAccountRepo domain.OrganizerBankAccountRepository

	categoryRepo domain.CategoryRepository
	venueRepo    domain.VenueRepository

	eventRepo             domain.EventRepository
	eventScheduleRepo     domain.EventScheduleRepository
	eventSettingRepo      domain.EventSettingRepository
	eventCancellationRepo domain.EventCancellationRepository
	eventContactRepo      domain.EventContactRepository

	seatLayoutRepository  domain.SeatLayoutRepository
	seatSectionRepository domain.SeatSectionRepository
	seatRowRepository     domain.SeatRowRepository
	seatRepository        domain.SeatRepository

	ticketTypeRepo domain.TicketTypeRepository
	ticketRepo     domain.TicketRepository

	seatReservationRepo      domain.SeatReservationRepository
	checkoutRepo             domain.CheckoutRepository
	bookingRepo              domain.BookingRepository
	paymentRepo              domain.PaymentRepository
	razorpayWebhookEventRepo domain.RazorpayWebhookEventRepository
}

func NewTransactionManager(
	db *gorm.DB,
	logger *slog.Logger,
) *TransactionManager {
	return &TransactionManager{
		db:     db,
		logger: logger,
	}
}

func (m *TransactionManager) WithinTransaction(
	fn func(tx domain.TransactionRepositories) error,
) error {
	return m.db.Transaction(func(txDB *gorm.DB) error {
		txRepos := &transactionRepositories{
			userRepo:                NewUserRepository(txDB, m.logger),
			pendingRegistrationRepo: NewPendingRegistrationRepository(txDB),
			passwordResetTokenRepo:  NewPasswordResetTokenRepository(txDB),
			organizerApplicationRepo: NewOrganizerApplicationRepository(
				txDB,
				m.logger,
			),

			organizerRepo: NewOrganizerRepository(
				txDB,
				m.logger,
			),

			organizerProfileRepo: NewOrganizerProfileRepository(
				txDB,
				m.logger,
			),

			organizerAddressRepo: NewOrganizerAddressRepository(
				txDB,
				m.logger,
			),

			organizerBankAccountRepo: NewOrganizerBankAccountRepository(
				txDB,
				m.logger,
			),

			categoryRepo: NewCategoryRepository(
				txDB,
				m.logger,
			),

			venueRepo: NewVenueRepository(
				txDB,
				m.logger,
			),

			eventRepo: NewEventRepository(
				txDB,
				m.logger,
			),

			eventScheduleRepo: NewEventScheduleRepository(
				txDB,
				m.logger,
			),

			eventSettingRepo: NewEventSettingRepository(
				txDB,
				m.logger,
			),

			eventCancellationRepo: NewEventCancellationRepository(
				txDB,
				m.logger,
			),

			eventContactRepo: NewEventContactRepository(
				txDB,
				m.logger,
			),

			seatLayoutRepository:  NewSeatLayoutRepository(txDB, m.logger),
			seatSectionRepository: NewSeatSectionRepository(txDB, m.logger),
			seatRowRepository:     NewSeatRowRepository(txDB, m.logger),
			seatRepository:        NewSeatRepository(txDB, m.logger),

			ticketTypeRepo: NewTicketTypeRepository(txDB, m.logger),
			ticketRepo:     NewTicketRepository(txDB, m.logger),

			seatReservationRepo:      NewSeatReservationRepository(txDB, m.logger),
			checkoutRepo:             NewCheckoutRepository(txDB, m.logger),
			bookingRepo:              NewBookingRepository(txDB, m.logger),
			paymentRepo:              NewPaymentRepository(txDB, m.logger),
			razorpayWebhookEventRepo: NewRazorpayWebhookEventRepository(txDB, m.logger),
		}

		return fn(txRepos)
	})
}

func (r *transactionRepositories) UserRepository() domain.UserRepository {
	return r.userRepo
}

func (r *transactionRepositories) PendingRegistrationRepository() domain.PendingRegistrationRepository {
	return r.pendingRegistrationRepo
}

func (r *transactionRepositories) PasswordResetTokenRepository() domain.PasswordResetTokenRepository {
	return r.passwordResetTokenRepo
}

func (r *transactionRepositories) OrganizerApplicationRepository() domain.OrganizerApplicationRepository {
	return r.organizerApplicationRepo
}

func (r *transactionRepositories) OrganizerRepository() domain.OrganizerRepository {
	return r.organizerRepo
}

func (r *transactionRepositories) OrganizerProfileRepository() domain.OrganizerProfileRepository {
	return r.organizerProfileRepo
}

func (r *transactionRepositories) OrganizerAddressRepository() domain.OrganizerAddressRepository {
	return r.organizerAddressRepo
}

func (r *transactionRepositories) OrganizerBankAccountRepository() domain.OrganizerBankAccountRepository {
	return r.organizerBankAccountRepo
}

func (r *transactionRepositories) CategoryRepository() domain.CategoryRepository {
	return r.categoryRepo
}

func (r *transactionRepositories) VenueRepository() domain.VenueRepository {
	return r.venueRepo
}

func (r *transactionRepositories) EventRepository() domain.EventRepository {
	return r.eventRepo
}

func (r *transactionRepositories) EventScheduleRepository() domain.EventScheduleRepository {
	return r.eventScheduleRepo
}

func (r *transactionRepositories) EventSettingRepository() domain.EventSettingRepository {
	return r.eventSettingRepo
}

func (r *transactionRepositories) EventCancellationRepository() domain.EventCancellationRepository {
	return r.eventCancellationRepo
}

func (r *transactionRepositories) SeatLayoutRepository() domain.SeatLayoutRepository {
	return r.seatLayoutRepository
}

func (r *transactionRepositories) SeatSectionRepository() domain.SeatSectionRepository {
	return r.seatSectionRepository
}

func (r *transactionRepositories) SeatRowRepository() domain.SeatRowRepository {
	return r.seatRowRepository
}

func (r *transactionRepositories) SeatRepository() domain.SeatRepository {
	return r.seatRepository
}

func (r *transactionRepositories) EventContactRepository() domain.EventContactRepository {
	return r.eventContactRepo
}

func (r *transactionRepositories) TicketTypeRepository() domain.TicketTypeRepository {
	return r.ticketTypeRepo
}

func (r *transactionRepositories) SeatReservationRepository() domain.SeatReservationRepository {
	return r.seatReservationRepo
}

func (r *transactionRepositories) CheckoutRepository() domain.CheckoutRepository {
	return r.checkoutRepo
}

func (r *transactionRepositories) BookingRepository() domain.BookingRepository {
	return r.bookingRepo
}

func (r *transactionRepositories) PaymentRepository() domain.PaymentRepository {
	return r.paymentRepo
}

func (r *transactionRepositories) RazorpayWebhookEventRepository() domain.RazorpayWebhookEventRepository {
	return r.razorpayWebhookEventRepo
}

func (r *transactionRepositories) TicketRepository() domain.TicketRepository {
	return r.ticketRepo
}
