package repository

import (
	"errors"
	"log/slog"
	"time"

	"github.com/adhithyan443/EventHub/backend/internal/domain"
	"github.com/adhithyan443/EventHub/backend/internal/repository/models"
	"github.com/google/uuid"
	"gorm.io/gorm"
)

type EventScheduleRepository struct {
	db     *gorm.DB
	logger *slog.Logger
}

func NewEventScheduleRepository(
	db *gorm.DB,
	logger *slog.Logger,
) *EventScheduleRepository {
	return &EventScheduleRepository{
		db:     db,
		logger: logger,
	}
}

func (r *EventScheduleRepository) Create(
	schedule *domain.EventSchedule,
) error {
	scheduleModel := toEventScheduleModel(schedule)

	if err := r.db.Create(scheduleModel).Error; err != nil {
		r.logger.Error(
			"event_schedule_create_failed",
			"event_id", schedule.EventID,
			"error", err,
		)

		return err
	}

	*schedule = *toEventScheduleDomain(scheduleModel)

	r.logger.Info(
		"event_schedule_created",
		"event_id", schedule.EventID,
		"schedule_id", schedule.ID,
	)

	return nil
}

func (r *EventScheduleRepository) FindByEventID(
	eventID uuid.UUID,
) (*domain.EventSchedule, error) {
	var scheduleModel models.EventScheduleModel

	if err := r.db.
		Where("event_id = ?", eventID).
		First(&scheduleModel).Error; err != nil {

		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, domain.ErrEventNotFound
		}

		r.logger.Error(
			"event_schedule_find_by_event_id_failed",
			"event_id", eventID,
			"error", err,
		)

		return nil, err
	}

	return toEventScheduleDomain(&scheduleModel), nil
}

func (r *EventScheduleRepository) Update(
	schedule *domain.EventSchedule,
) error {
	if schedule == nil {
		return errors.New("event schedule cannot be nil")
	}

	scheduleModel := toEventScheduleModel(schedule)

	result := r.db.
		Model(&models.EventScheduleModel{}).
		Where("event_id = ?", schedule.EventID).
		Updates(map[string]interface{}{
			"event_date": scheduleModel.EventDate,
			"start_time": scheduleModel.StartTime,
			"end_time":   scheduleModel.EndTime,
			"is_all_day": scheduleModel.IsAllDay,
			"updated_at": time.Now(),
		})

	if result.Error != nil {
		r.logger.Error(
			"event_schedule_update_failed",
			"event_id", schedule.EventID,
			"error", result.Error,
		)

		return result.Error
	}

	if result.RowsAffected == 0 {
		r.logger.Warn(
			"event_schedule_update_not_found",
			"event_id", schedule.EventID,
		)

		return domain.ErrEventNotFound
	}

	r.logger.Info(
		"event_schedule_updated",
		"event_id", schedule.EventID,
		"schedule_id", schedule.ID,
	)

	return nil
}

func (r *EventScheduleRepository) DeleteByEventID(eventID uuid.UUID) error {
	result := r.db.Where("event_id = ?", eventID).Delete(&models.EventScheduleModel{})
	if result.Error != nil {
		r.logger.Error(
			"event_schedule_delete_failed",
			"event_id", eventID,
			"error", result.Error,
		)
		return result.Error
	}

	r.logger.Info("event_schedule_deleted", "event_id", eventID)
	return nil
}

func toEventScheduleModel(
	schedule *domain.EventSchedule,
) *models.EventScheduleModel {
	var startTime *string
	var endTime *string

	if !schedule.StartTime.IsZero() {
		start := schedule.StartTime.Format("15:04:05")
		startTime = &start
	}

	if !schedule.EndTime.IsZero() {
		end := schedule.EndTime.Format("15:04:05")
		endTime = &end
	}

	return &models.EventScheduleModel{
		ID:        schedule.ID,
		EventID:   schedule.EventID,
		EventDate: schedule.EventDate,
		StartTime: startTime,
		EndTime:   endTime,
		IsAllDay:  schedule.IsAllDay,
		CreatedAt: schedule.CreatedAt,
		UpdatedAt: schedule.UpdatedAt,
	}
}

func toEventScheduleDomain(
	scheduleModel *models.EventScheduleModel,
) *domain.EventSchedule {
	var startTime time.Time
	var endTime time.Time

	if scheduleModel.StartTime != nil && *scheduleModel.StartTime != "" {
		if t, err := time.Parse("15:04:05", *scheduleModel.StartTime); err == nil {
			startTime = t
		} else if t, err := time.Parse("15:04", *scheduleModel.StartTime); err == nil {
			startTime = t
		}
	}

	if scheduleModel.EndTime != nil && *scheduleModel.EndTime != "" {
		if t, err := time.Parse("15:04:05", *scheduleModel.EndTime); err == nil {
			endTime = t
		} else if t, err := time.Parse("15:04", *scheduleModel.EndTime); err == nil {
			endTime = t
		}
	}

	return &domain.EventSchedule{
		ID:        scheduleModel.ID,
		EventID:   scheduleModel.EventID,
		EventDate: scheduleModel.EventDate,
		StartTime: startTime,
		EndTime:   endTime,
		IsAllDay:  scheduleModel.IsAllDay,
		CreatedAt: scheduleModel.CreatedAt,
		UpdatedAt: scheduleModel.UpdatedAt,
	}
}
