package database

import (
	"github.com/adhithyan443/EventHub/backend/internal/repository/models"
	"gorm.io/gorm"
)

func Migrate(db *gorm.DB) error {
	return db.AutoMigrate(

		&models.UserModel{},
		&models.RefreshTokenModel{},
		&models.PasswordResetTokenModel{},
		&models.PendingRegistrationModel{},

		&models.OrganizerApplicationModel{},

		&models.OrganizerModel{},
		&models.OrganizerProfileModel{},
		&models.OrganizerAddressModel{},
		&models.OrganizerBankAccountModel{},

		&models.CategoryModel{},
		&models.VenueModel{},

		&models.EventModel{},
		&models.EventScheduleModel{},
		&models.EventSettingModel{},
		&models.EventCancellationModel{},
	)
}
