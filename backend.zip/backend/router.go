package main

import (
	"log/slog"
	"net/http"
	"time"

	"github.com/adhithyan443/EventHub/backend/internal/delivery/http/handler"
	"github.com/adhithyan443/EventHub/backend/internal/delivery/http/middleware"
	"github.com/adhithyan443/EventHub/backend/internal/token"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func setupRouter(
	logger *slog.Logger,
	authHandler *handler.AuthHandler,
	organizerApplicationHandler *handler.OrganizerApplicationHandler,
	organizerProfileHandler *handler.OrganizerProfileHandler,
	categoryHandler *handler.CategoryHandler,
	eventHandler *handler.EventHandler,
	seatLayoutHandler *handler.SeatLayoutHandler,
	reservationHandler *handler.ReservationHandler,
	checkoutHandler *handler.CheckoutHandler,
	bookingHandler *handler.BookingHandler,
	paymentHandler *handler.PaymentHandler,
	ticketHandler *handler.TicketHandler,
	jwtService *token.JWTService,
) *gin.Engine {
	router := gin.New()

	// Global middleware.
	router.Use(

		cors.New(cors.Config{
			AllowOrigins: []string{
				"http://localhost:5173",
				"http://127.0.0.1:5173",
			},
			AllowMethods: []string{
				http.MethodGet,
				http.MethodPost,
				http.MethodPut,
				http.MethodPatch,
				http.MethodDelete,
				http.MethodOptions,
			},
			AllowHeaders: []string{
				"Origin",
				"Content-Type",
				"Accept",
				"Authorization",
			},
			AllowCredentials: true,
		}),
		middleware.RequestID(),
		middleware.Logger(logger),
		middleware.Recovery(logger),
		middleware.ErrorHandler(logger),
	)

	registerHealthRoutes(router)
	registerAuthRoutes(router, authHandler, jwtService, logger)

	registerOrganizerRoutes(
		router,
		organizerApplicationHandler,
		organizerProfileHandler,
		eventHandler,
		seatLayoutHandler,
		jwtService,
	)

	registerAdminRoutes(router, organizerApplicationHandler, jwtService)
	registerCategoryRoutes(router, categoryHandler)
	registerPublicEventRoutes(router, eventHandler, seatLayoutHandler)
	registerReservationRoutes(router, reservationHandler, jwtService)
	registerCheckoutRoutes(router, checkoutHandler, jwtService)
	registerBookingRoutes(router, bookingHandler, jwtService)
	registerPaymentRoutes(router, paymentHandler, jwtService)
	registerTicketRoutes(router, ticketHandler, jwtService)

	return router
}

func registerHealthRoutes(router *gin.Engine) {
	router.GET("/health", func(ctx *gin.Context) {
		ctx.JSON(http.StatusOK, gin.H{
			"status": "ok",
		})
	})
}

func registerAuthRoutes(
	router *gin.Engine,
	authHandler *handler.AuthHandler,
	jwtService *token.JWTService,
	logger *slog.Logger,
) {
	rateLimiter := middleware.NewRateLimiter(
		5,
		time.Minute,
		logger,
	)

	api := router.Group("/api/v1")
	auth := api.Group("/auth")

	// Public authentication endpoints.
	auth.POST(
		"/register",
		rateLimiter.Middleware(),
		authHandler.Register,
	)

	auth.POST(
		"/verify-otp",
		rateLimiter.Middleware(),
		authHandler.VerifyOTP,
	)

	auth.POST(
		"/resend-otp",
		rateLimiter.Middleware(),
		authHandler.ResendOTP,
	)

	auth.POST(
		"/login",
		rateLimiter.Middleware(),
		authHandler.Login,
	)

	auth.POST(
		"/forgot-password",
		rateLimiter.Middleware(),
		authHandler.ForgotPassword,
	)

	auth.POST(
		"/reset-password",
		authHandler.ResetPassword,
	)

	auth.GET(
		"/google",
		authHandler.GoogleLogin,
	)

	auth.GET(
		"/google/callback",
		authHandler.GoogleCallback,
	)

	// Token endpoints.
	auth.POST(
		"/refresh-token",
		authHandler.RefreshToken,
	)

	auth.POST(
		"/logout",
		middleware.Auth(jwtService),
		authHandler.Logout,
	)

	// Authenticated user endpoint.
	auth.GET(
		"/me",
		middleware.Auth(jwtService),
		authHandler.Me,
	)
}

func registerOrganizerRoutes(
	router *gin.Engine,
	organizerApplicationHandler *handler.OrganizerApplicationHandler,
	organizerProfileHandler *handler.OrganizerProfileHandler,
	eventHandler *handler.EventHandler,
	seatLayoutHandler *handler.SeatLayoutHandler,
	jwtService *token.JWTService,
) {
	api := router.Group("/api/v1")

	organizer := api.Group("/organizers")
	organizer.Use(
		middleware.Auth(jwtService),
		// middleware.RequireRole("ORGANIZER"),
	)

	// Customer organizer-application endpoints.
	organizer.POST(
		"/apply",
		organizerApplicationHandler.SubmitApplication,
	)

	organizer.GET(
		"/application",
		organizerApplicationHandler.GetMyApplication,
	)

	organizer.GET(
		"/profile",
		organizerProfileHandler.GetProfile,
	)

	// Organizer event endpoints.
	organizer.POST(
		"/events",
		eventHandler.CreateEvent,
	)

	organizer.POST(
		"/events/:id/seat-layout",
		seatLayoutHandler.CreateSeatLayout,
	)

	organizer.PUT(
		"/events/:id/seat-layout",
		seatLayoutHandler.UpdateSeatLayout,
	)

	organizer.PUT(
		"/events/:id",
		eventHandler.UpdateEvent,
	)

	organizer.DELETE(
		"/events/:id",
		eventHandler.DeleteEvent,
	)

	organizer.GET(
		"/events",
		eventHandler.GetMyEvents,
	)

	organizer.GET(
		"/events/:id",
		eventHandler.GetEventDetails,
	)

	organizer.PATCH(
		"/events/:id/publish",
		eventHandler.PublishEvent,
	)
}

func registerAdminRoutes(
	router *gin.Engine,
	organizerApplicationHandler *handler.OrganizerApplicationHandler,
	jwtService *token.JWTService,
) {
	api := router.Group("/api/v1")

	admin := api.Group("/admin")
	admin.Use(
		middleware.Auth(jwtService),
		middleware.RequireRole("ADMIN"),
	)

	admin.GET(
		"/organizer-applications",
		organizerApplicationHandler.ListApplications,
	)

	admin.GET(
		"/organizer-applications/:id",
		organizerApplicationHandler.GetApplication,
	)

	admin.PATCH(
		"/organizer-applications/:id/approve",
		organizerApplicationHandler.ApproveApplication,
	)

	admin.PATCH(
		"/organizer-applications/:id/reject",
		organizerApplicationHandler.RejectApplication,
	)
}

func registerCategoryRoutes(
	router *gin.Engine,
	categoryHandler *handler.CategoryHandler,
) {
	api := router.Group("/api/v1")

	api.GET(
		"/categories",
		categoryHandler.GetCategories,
	)
}

func registerPublicEventRoutes(
	router *gin.Engine,
	eventHandler *handler.EventHandler,
	seatLayoutHandler *handler.SeatLayoutHandler,
) {
	api := router.Group("/api/v1")

	api.GET(
		"/events",
		eventHandler.ListPublicEvents,
	)

	api.GET(
		"/events/:eventId",
		eventHandler.GetPublicEventDetails,
	)

	api.GET(
		"/events/:eventId/seat-layout",
		seatLayoutHandler.GetPublicSeatLayout,
	)
}

func registerReservationRoutes(
	router *gin.Engine,
	reservationHandler *handler.ReservationHandler,
	jwtService *token.JWTService,
) {
	api := router.Group("/api/v1")

	api.POST(
		"/events/:eventId/reservations",
		middleware.Auth(jwtService),
		reservationHandler.CreateReservation,
	)

	api.POST(
		"/bookings/reserve",
		middleware.Auth(jwtService),
		reservationHandler.CreateReservation,
	)

	api.DELETE(
		"/reservations/:reservationId",
		middleware.Auth(jwtService),
		reservationHandler.CancelReservation,
	)
}

func registerCheckoutRoutes(
	router *gin.Engine,
	checkoutHandler *handler.CheckoutHandler,
	jwtService *token.JWTService,
) {
	api := router.Group("/api/v1")
	api.Use(middleware.Auth(jwtService))

	api.POST("/bookings/checkout", checkoutHandler.CreateCheckout)
}

func registerPaymentRoutes(
	router *gin.Engine,
	paymentHandler *handler.PaymentHandler,
	jwtService *token.JWTService,
) {
	api := router.Group("/api/v1")

	// Public payment webhook endpoint - verified cryptographically via Razorpay HMAC signature.
	api.POST("/payments/webhook", paymentHandler.RazorpayWebhook)

	payments := api.Group("/payments")
	payments.Use(middleware.Auth(jwtService))

	payments.POST("", paymentHandler.CreatePayment)

	payments.POST("/verify", paymentHandler.VerifyPayment)
}

func registerTicketRoutes(
	router *gin.Engine,
	ticketHandler *handler.TicketHandler,
	jwtService *token.JWTService,
) {
	tickets := router.Group("/api/v1/tickets")
	tickets.Use(middleware.Auth(jwtService))

	tickets.GET("", ticketHandler.GetMyTickets)
	tickets.GET("/:id", ticketHandler.GetMyTicket)

	tickets.GET("/:id/download", ticketHandler.DownloadTicketPDF)
}

func registerBookingRoutes(
	router *gin.Engine,
	bookingHandler *handler.BookingHandler,
	jwtService *token.JWTService,
) {
	bookings := router.Group("/api/v1/bookings")
	bookings.Use(middleware.Auth(jwtService))

	bookings.GET("", bookingHandler.GetMyBookings)
	bookings.GET("/:id", bookingHandler.GetBookingByID)
}
